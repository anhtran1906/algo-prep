/**
 * Created by anhtran on 5/26/17.
 */
import java.util.Scanner;
public class Arrays572A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nA = sc.nextInt();
        int nB = sc.nextInt();
        int k = sc.nextInt();
        int m = sc.nextInt();
        int[] arrA = new int[nA];
        int[] arrB = new int[nB];
        boolean res = false;
        for (int i = 0; i < nA; i++) {
            arrA[i] = sc.nextInt();
        }
        for (int i = 0; i < nB; i++) {
            arrB[i] = sc.nextInt();
        }

        if(arrA[k-1] >= arrB[0]) {
            res = false;
        }
        else {
            int i = 0;
            int j = 0;
            while (i < k) {
                while (j < m) {
                    if (arrA[i] < arrB[j]) {
                        res = true;
                    }
                    j++;
                }
                i++;
            }
        }
        if(res) {
            System.out.println("YES");
        }
        else {
            System.out.println("NO");
        }
    }
}
