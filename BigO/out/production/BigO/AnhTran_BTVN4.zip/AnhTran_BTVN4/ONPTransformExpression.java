import java.util.Scanner;
import java.util.Stack;

/**
 * Created by anhtran on 6/5/17.
 */
public class ONPTransformExpression {

    private static String transform (String exp) {
        int count = 0;
        Stack<Character> ops = new Stack<Character>();
        StringBuffer result = new StringBuffer();
        int i = 0;

        while (count > 0 || i < exp.length()){
            if(exp.charAt(i) == '(') {
                count++;
            }
            else if (exp.charAt(i) == ')'){
                count--;
                result.append(ops.pop());
            }
            else if (!isOperators(exp.charAt(i))) {
                result.append(exp.charAt(i));
            }
            else if (isOperators(exp.charAt(i))) {
                ops.push(exp.charAt(i));
            }
            i++;
        }
        return result.toString();
    }

    private static boolean isOperators(char c) {
        char[] chars = new char[5];
        String s = "+-*/^";
        chars = s.toCharArray();
        for (char i: chars){
            if(i == c) {
                return true;
            }
        }
        return false;
    }

    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] results = new String[n];
        String line = sc.nextLine();
        int i = 0;
        while (sc.hasNext() && i < n) {
            line = sc.nextLine();
            results[i] = transform(line);
            i++;
        }

        for(String s: results){
            System.out.println(s);
        }

    }
}
