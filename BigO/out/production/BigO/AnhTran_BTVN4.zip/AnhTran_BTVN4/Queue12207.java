import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 * Created by anhtran on 6/6/17.
 */
public class Queue12207 {

    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int caseCount = 0;
        while (sc.hasNext()) {
            int p = sc.nextInt();
            int c = sc.nextInt();
            if(p == 0 && c == 0) {
                break;
            }
            else {
                caseCount++;
                System.out.println("Case " + caseCount + ":");
                int size = p > 1000 ? 1000 : p;
                Queue<Integer> queue = new LinkedList<Integer>();
                Queue<Integer> tempQueue = new LinkedList<Integer>();
                for (int i = 1; i <= size; i++) {
                    queue.add(i);
                }
                while (c > 0) {
                    String command = sc.next();
                    if (command.equals("N")) {
                        int temp = queue.poll();
                        System.out.println(temp);
                        queue.add(temp);
                        c--;
                    }
                    else {
                        int exp = Integer.parseInt(sc.next());
                        queue.remove(exp);
                        while (!queue.isEmpty()) {
                            tempQueue.add(queue.poll());
                        }
                        queue.add(exp);
                        while (!tempQueue.isEmpty()) {
                            queue.add(tempQueue.poll());
                        }
                        c--;
                    }
                }
            }
        }
    }
}
